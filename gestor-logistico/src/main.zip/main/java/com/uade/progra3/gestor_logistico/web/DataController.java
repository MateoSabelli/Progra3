package com.uade.progra3.gestor_logistico.web;

import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.uade.progra3.gestor_logistico.service.DataInitService;

@RestController
@RequestMapping("/data")
public class DataController {

    private final DataInitService dataInitService;

    public DataController(DataInitService dataInitService) {
        this.dataInitService = dataInitService;
    }

    @PostMapping("/init")
    public ResponseEntity<Map<String, String>> initializeData() {
        try {
            String message = dataInitService.initializeData();
            return ResponseEntity.ok(Map.of("status", "success", "message", message));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("status", "error", "message", "Error al inicializar: " + e.getMessage()));
        }
    }

    @DeleteMapping("/clear")
    public ResponseEntity<Map<String, String>> clearData() {
        try {
            String message = dataInitService.clearData();
            return ResponseEntity.ok(Map.of("status", "success", "message", message));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("status", "error", "message", "Error al limpiar: " + e.getMessage()));
        }
    }
}
