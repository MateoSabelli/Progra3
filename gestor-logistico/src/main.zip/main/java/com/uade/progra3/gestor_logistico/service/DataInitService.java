package com.uade.progra3.gestor_logistico.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.uade.progra3.gestor_logistico.domain.Centro;
import com.uade.progra3.gestor_logistico.domain.Ruta;
import com.uade.progra3.gestor_logistico.repo.CentroRepository;

@Service
public class DataInitService {

    private final CentroRepository repo;

    public DataInitService(CentroRepository repo) {
        this.repo = repo;
    }

    @Transactional
    public String initializeData() {
        try {
            // Limpiar datos existentes
            repo.deleteAll();

            // Crear centros logísticos sin rutas primero
            Centro ca001 = repo.save(new Centro("CA001", "Centro Norte", "Buenos Aires", 1000));
            Centro ca002 = repo.save(new Centro("CA002", "Centro Sur", "Córdoba", 800));
            Centro ca003 = repo.save(new Centro("CA003", "Centro Este", "Rosario", 600));
            Centro ca004 = repo.save(new Centro("CA004", "Centro Oeste", "Mendoza", 500));
            Centro ca005 = repo.save(new Centro("CA005", "Centro Litoral", "Santa Fe", 700));
            Centro ca006 = repo.save(new Centro("CA006", "Centro Patagonia", "Neuquén", 400));

            // Esperar un poco para asegurar que Neo4j persista los nodos
            Thread.sleep(500);

            // Ahora agregar las rutas
            // Desde CA001 (Buenos Aires)
            ca001.getRutas().add(new Ruta(ca002, 60, 1500, 700));
            ca001.getRutas().add(new Ruta(ca003, 35, 800, 300));
            ca001.getRutas().add(new Ruta(ca005, 70, 1200, 500));

            // Desde CA002 (Córdoba)
            ca002.getRutas().add(new Ruta(ca001, 60, 1500, 700));
            ca002.getRutas().add(new Ruta(ca003, 50, 1000, 400));
            ca002.getRutas().add(new Ruta(ca004, 90, 2000, 600));
            ca002.getRutas().add(new Ruta(ca005, 45, 900, 350));

            // Desde CA003 (Rosario)
            ca003.getRutas().add(new Ruta(ca001, 35, 800, 300));
            ca003.getRutas().add(new Ruta(ca002, 50, 1000, 400));
            ca003.getRutas().add(new Ruta(ca005, 40, 700, 200));

            // Desde CA004 (Mendoza)
            ca004.getRutas().add(new Ruta(ca002, 90, 2000, 600));
            ca004.getRutas().add(new Ruta(ca006, 120, 2500, 800));

            // Desde CA005 (Santa Fe)
            ca005.getRutas().add(new Ruta(ca001, 70, 1200, 500));
            ca005.getRutas().add(new Ruta(ca002, 45, 900, 350));
            ca005.getRutas().add(new Ruta(ca003, 40, 700, 200));

            // Desde CA006 (Neuquén)
            ca006.getRutas().add(new Ruta(ca004, 120, 2500, 800));

            // Guardar todos los centros con sus rutas
            repo.save(ca001);
            repo.save(ca002);
            repo.save(ca003);
            repo.save(ca004);
            repo.save(ca005);
            repo.save(ca006);

            return "Base de datos inicializada con 6 centros y múltiples rutas";
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Error al inicializar la base de datos: " + e.getMessage(), e);
        }
    }

    @Transactional
    public String clearData() {
        repo.deleteAll();
        return "Todos los datos han sido eliminados de la base de datos";
    }
}
