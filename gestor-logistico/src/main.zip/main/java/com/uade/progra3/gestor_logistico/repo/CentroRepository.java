package com.uade.progra3.gestor_logistico.repo;
import org.springframework.data.neo4j.repository.ReactiveNeo4jRepository;
import org.springframework.data.neo4j.repository.query.Query;

import com.uade.progra3.gestor_logistico.domain.Centro;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface CentroRepository extends ReactiveNeo4jRepository<Centro, Long> {

  @Query("""
    MATCH (c:Centro)
    OPTIONAL MATCH (c)-[r:RUTA]->(d:Centro)
    RETURN c, collect(r), collect(d)
  """)
  Flux<Centro> loadGraph();

  // Crear/actualizar una ruta dirigida
  @Query("""
    MERGE (o:Centro {id:$from})
    MERGE (d:Centro {id:$to})
    MERGE (o)-[r:RUTA]->(d)
    SET r.tiempoMin = $tiempoMin, r.costo = $costo, r.distKm = $distKm
    RETURN 1
  """)
  Mono<Integer> crearRuta(String from, String to, int tiempoMin, int costo, int distKm);

  // Borrar una ruta dirigida
  @Query("""
    MATCH (:Centro {id:$from})-[r:RUTA]->(:Centro {id:$to})
    DELETE r
    RETURN 1
  """)
  Mono<Integer> borrarRuta(String from, String to);
}
