package com.uade.progra3.gestor_logistico;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestorLogisticoApplicationTests {

	@Test
	void contextLoads() {
	}

}
