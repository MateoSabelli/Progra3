package com.uade.progra3.gestor_logistico;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestorLogisticoApplication {
	public static void main(String[] args) {
		SpringApplication.run(GestorLogisticoApplication.class, args);
		System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@qqq");
	}
}
